#include <jni.h>
#include <vector>
#include <cmath>
#include <algorithm>
#include "world/dio.h"
#include "world/harvest.h"
#include "world/stonemask.h"
#include "world/cheaptrick.h"
#include "world/d4c.h"
#include "world/synthesis.h"

static const double LN2 = 0.6931471805599453;

// Warp sumbu frekuensi (menggeser formant): out[k] = in[k / ratio]
static void warp(const double* in, double* out, int bins, double ratio) {
    for (int k = 0; k < bins; k++) {
        double pos = k / ratio;
        int i = (int)pos;
        if (i >= bins - 1) { out[k] = in[bins - 1]; continue; }
        double f = pos - i;
        out[k] = in[i] * (1.0 - f) + in[i + 1] * f;
    }
}

// params: [0]pitch [1]formant [2]speed [3]targetStd(semiton) [4]tilt(st) [5]fall(st) [6]smooth(frame) [7]pauseScale
extern "C" JNIEXPORT jdoubleArray JNICALL
Java_com_suaraku_app_NativeVoice_process(JNIEnv* env, jobject, jdoubleArray input, jint fs, jdoubleArray params) {
    const jsize n = env->GetArrayLength(input);
    double prm[13];
    env->GetDoubleArrayRegion(params, 0, 13, prm);
    const double pitch = prm[0], formant = prm[1], speed = prm[2];
    const double targetStd = prm[3], tilt = prm[4], fall = prm[5];
    const int smoothH = (int)prm[6];
    const double pauseScale = prm[7];
    const double breath = prm[8], bright = prm[9], vib = prm[10], robotHz = prm[11];
    const bool whisper = prm[12] > 0.5;

    std::vector<double> x(n);
    env->GetDoubleArrayRegion(input, 0, n, x.data());
    if (n < fs / 4) {
        jdoubleArray o = env->NewDoubleArray(n);
        env->SetDoubleArrayRegion(o, 0, n, x.data());
        return o;
    }

    // ---- Analisis WORLD ----
    const double fp = 5.0;
    HarvestOption hv; InitializeHarvestOption(&hv);
    hv.f0_floor = 70.0; hv.f0_ceil = 600.0; hv.frame_period = fp;
    const int f0len = GetSamplesForHarvest(fs, n, fp);
    std::vector<double> t(f0len), rf0(f0len);
    Harvest(x.data(), n, fs, &hv, t.data(), rf0.data());

    CheapTrickOption ct; InitializeCheapTrickOption(fs, &ct);
    ct.f0_floor = 72.0;
    ct.fft_size = GetFFTSizeForCheapTrick(fs, &ct);
    const int fft = ct.fft_size, bins = fft / 2 + 1;

    std::vector<double> spBuf((size_t)f0len * bins), apBuf((size_t)f0len * bins);
    std::vector<double*> sp(f0len), ap(f0len);
    for (int i = 0; i < f0len; i++) { sp[i] = &spBuf[(size_t)i * bins]; ap[i] = &apBuf[(size_t)i * bins]; }
    CheapTrick(x.data(), n, fs, t.data(), rf0.data(), f0len, &ct, sp.data());
    D4COption d4c; InitializeD4COption(&d4c); d4c.threshold = 0.85;
    D4C(x.data(), n, fs, t.data(), rf0.data(), f0len, fft, &d4c, ap.data());

    // ---- Deteksi jeda (energi rendah >= 75 ms) ----
    std::vector<double> en(f0len);
    double maxE = 0;
    const int hw = fs / 100;
    for (int i = 0; i < f0len; i++) {
        int c = (int)(t[i] * fs);
        int lo = std::max(0, c - hw), hi = std::min((int)n, c + hw);
        double s = 0;
        for (int k = lo; k < hi; k++) s += x[k] * x[k];
        en[i] = std::sqrt(s / std::max(1, hi - lo));
        maxE = std::max(maxE, en[i]);
    }
    const double thr = 0.03 * maxE;
    const int MINGAP = 15;
    std::vector<char> gap(f0len, 0);
    for (int i = 0; i < f0len;) {
        if (en[i] < thr) {
            int j = i;
            while (j < f0len && en[j] < thr) j++;
            if (j - i >= MINGAP) for (int k = i; k < j; k++) gap[k] = 1;
            i = j;
        } else i++;
    }

    // ---- Peta frame: skala jeda, lalu kecepatan ----
    std::vector<int> map; std::vector<char> mgap;
    for (int i = 0; i < f0len;) {
        if (gap[i]) {
            int j = i;
            while (j < f0len && gap[j]) j++;
            int len = j - i;
            int newLen = std::max(1, (int)(len * pauseScale + 0.5));
            for (int k = 0; k < newLen; k++) {
                map.push_back(i + std::min(len - 1, (int)(k / pauseScale)));
                mgap.push_back(1);
            }
            i = j;
        } else { map.push_back(i); mgap.push_back(0); i++; }
    }
    const int outFrames = std::max(1, (int)(map.size() / speed));
    std::vector<int> srcIdx(outFrames);
    std::vector<char> ngap(outFrames), vo(outFrames);
    std::vector<double> lf(outFrames, 0.0);
    for (int j = 0; j < outFrames; j++) {
        int m = std::min((int)map.size() - 1, (int)(j * speed + 0.5));
        srcIdx[j] = map[m];
        ngap[j] = mgap[m];
        vo[j] = rf0[srcIdx[j]] > 0;
        if (vo[j]) lf[j] = std::log(rf0[srcIdx[j]]);
    }

    // ---- Haluskan kontur pitch ----
    if (smoothH > 0) {
        std::vector<double> sm = lf;
        for (int j = 0; j < outFrames; j++) {
            if (!vo[j]) continue;
            double s = 0; int c = 0;
            for (int k = std::max(0, j - smoothH); k <= std::min(outFrames - 1, j + smoothH); k++)
                if (vo[k]) { s += lf[k]; c++; }
            sm[j] = s / c;
        }
        lf = sm;
    }

    // ---- Bentuk intonasi per frasa ----
    int j = 0;
    while (j < outFrames) {
        if (ngap[j]) { j++; continue; }
        int s = j, e = j;
        while (e < outFrames && !ngap[e]) {
            if (e - s >= 400 && !vo[e]) break;  // frasa terlalu panjang: potong di bagian tak bernada
            e++;
        }
        int fv = -1, lv = -1, cnt = 0; double sum = 0;
        for (int k = s; k < e; k++) if (vo[k]) { if (fv < 0) fv = k; lv = k; cnt++; sum += lf[k]; }
        if (cnt >= 3) {
            double mean = sum / cnt, var = 0;
            for (int k = s; k < e; k++) if (vo[k]) var += (lf[k] - mean) * (lf[k] - mean);
            double sdSt = std::sqrt(var / cnt) * 12.0 / LN2;
            double scale = 1.0;
            if (targetStd > 0 && sdSt > 0.01) scale = std::min(2.5, std::max(0.4, targetStd / sdSt));
            int span = std::max(1, lv - fv);
            int fl = std::min(60, lv - fv + 1);
            for (int k = fv; k <= lv; k++) {
                if (!vo[k]) continue;
                double l = mean + (lf[k] - mean) * scale;
                double pos = (double)(k - fv) / span;
                l -= tilt * (pos - 0.5) * LN2 / 12.0;
                if (k > lv - fl) {
                    double q = (double)(k - (lv - fl)) / fl;
                    l -= fall * q * LN2 / 12.0;
                }
                lf[k] = l;
            }
        }
        j = (e > s) ? e : j + 1;
    }

    // ---- Susun parameter baru + geser formant ----
    std::vector<double> nsBuf((size_t)outFrames * bins), naBuf((size_t)outFrames * bins), nf0(outFrames);
    std::vector<double*> nsp(outFrames), nap(outFrames);
    std::vector<double> tg(bins, 1.0);  // kemiringan terang/gelap (power)
    if (bright != 0.0) {
        for (int b = 0; b < bins; b++) {
            double f = b * (double)fs / fft;
            double db = bright * std::log2(std::max(f, 100.0) / 1000.0);
            db = std::min(12.0, std::max(-12.0, db));
            tg[b] = std::pow(10.0, db / 10.0);
        }
    }
    if (vib > 0.0) {  // vibrato 5,5 Hz
        for (int k = 0; k < outFrames; k++)
            if (vo[k]) lf[k] += vib * LN2 / 12.0 * std::sin(6.283185307 * 5.5 * k * fp / 1000.0);
    }
    for (int k = 0; k < outFrames; k++) {
        nsp[k] = &nsBuf[(size_t)k * bins]; nap[k] = &naBuf[(size_t)k * bins];
        nf0[k] = (vo[k] && !whisper) ? (robotHz > 0.0 ? robotHz : std::min(1000.0, std::max(50.0, std::exp(lf[k]) * pitch))) : 0.0;
        warp(sp[srcIdx[k]], nsp[k], bins, formant);
        warp(ap[srcIdx[k]], nap[k], bins, formant);
        if (vo[k]) {  // kurangi desis pada bagian bernada
            for (int b = 0; b < bins; b++) { double v = std::max(0.0, nap[k][b]); nap[k][b] = v * std::sqrt(v); }
        }
        if (ngap[k]) {  // redam noise latar pada jeda
            for (int b = 0; b < bins; b++) nsp[k][b] *= 0.1;
        }
        if (breath > 0.0 && vo[k]) {
            for (int b = 0; b < bins; b++) nap[k][b] = nap[k][b] + (1.0 - nap[k][b]) * breath;
        }
        if (whisper) {
            for (int b = 0; b < bins; b++) nap[k][b] = 1.0;
        }
        if (bright != 0.0) {
            for (int b = 0; b < bins; b++) nsp[k][b] *= tg[b];
        }
    }

    const int ylen = (int)(outFrames * fp / 1000.0 * fs) + 1;
    std::vector<double> y(ylen, 0.0);
    Synthesis(nf0.data(), outFrames, nsp.data(), nap.data(), fft, fp, fs, ylen, y.data());

    jdoubleArray out = env->NewDoubleArray(ylen);
    env->SetDoubleArrayRegion(out, 0, ylen, y.data());
    return out;
}

// Median nada (Hz) suara sumber, 0 jika tidak terdeteksi
extern "C" JNIEXPORT jdouble JNICALL
Java_com_suaraku_app_NativeVoice_estimateF0(JNIEnv* env, jobject, jdoubleArray input, jint fs) {
    const jsize n = env->GetArrayLength(input);
    if (n < fs / 4) return 0.0;
    std::vector<double> x(n);
    env->GetDoubleArrayRegion(input, 0, n, x.data());
    DioOption dio; InitializeDioOption(&dio);
    dio.f0_floor = 70.0; dio.f0_ceil = 500.0; dio.frame_period = 10.0; dio.speed = 4;
    const int len = GetSamplesForDIO(fs, n, 10.0);
    std::vector<double> t(len), f0(len), rf0(len);
    Dio(x.data(), n, fs, &dio, t.data(), f0.data());
    StoneMask(x.data(), n, fs, t.data(), f0.data(), len, rf0.data());
    std::vector<double> v;
    for (int i = 0; i < len; i++) if (rf0[i] >= 70.0 && rf0[i] <= 500.0) v.push_back(rf0[i]);
    if (v.size() < 20) return 0.0;
    std::nth_element(v.begin(), v.begin() + v.size() / 2, v.end());
    return v[v.size() / 2];
}

// Kontur F0 per 10 ms (untuk RVC)
extern "C" JNIEXPORT jdoubleArray JNICALL
Java_com_suaraku_app_NativeVoice_f0Track(JNIEnv* env, jobject, jdoubleArray input, jint fs) {
    const jsize n = env->GetArrayLength(input);
    if (n < fs / 10) return env->NewDoubleArray(0);
    std::vector<double> x(n);
    env->GetDoubleArrayRegion(input, 0, n, x.data());
    HarvestOption hv; InitializeHarvestOption(&hv);
    hv.f0_floor = 50.0; hv.f0_ceil = 1100.0; hv.frame_period = 10.0;
    const int len = GetSamplesForHarvest(fs, n, 10.0);
    std::vector<double> t(len), f0(len);
    Harvest(x.data(), n, fs, &hv, t.data(), f0.data());
    jdoubleArray out = env->NewDoubleArray(len);
    env->SetDoubleArrayRegion(out, 0, len, f0.data());
    return out;
}
