package com.suaraku.app

object NativeVoice {
    init { System.loadLibrary("suaraku") }
    external fun f0Track(input: DoubleArray, fs: Int): DoubleArray
    external fun estimateF0(input: DoubleArray, fs: Int): Double
    external fun process(input: DoubleArray, fs: Int, params: DoubleArray): DoubleArray
}
