package com.suaraku.app

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import android.media.MediaPlayer
import android.provider.DocumentsContract
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun Slide(label: String, value: Double, range: ClosedFloatingPointRange<Float>, fmt: String, onChange: (Double) -> Unit) {
    Column {
        Text("$label: " + String.format(fmt, value))
        Slider(value = value.toFloat().coerceIn(range.start, range.endInclusive), onValueChange = { onChange(it.toDouble()) }, valueRange = range)
    }
}

fun saveCustoms(p: SharedPreferences, l: List<Effect>) {
    val a = JSONArray()
    l.forEach {
        a.put(JSONObject().put("n", it.name).put("f0", it.f0).put("fm", it.formant).put("sp", it.speed)
            .put("br", it.breath).put("bt", it.bright).put("vb", it.vib).put("rb", it.robotHz).put("wh", it.whisper))
    }
    p.edit().putString("customs", a.toString()).apply()
}

fun loadCustoms(p: SharedPreferences): List<Effect> = try {
    val a = JSONArray(p.getString("customs", "[]"))
    (0 until a.length()).map {
        val o = a.getJSONObject(it)
        Effect(o.getString("n"), o.getDouble("f0"), o.getDouble("fm"), o.getDouble("sp"),
            o.getDouble("br"), o.getDouble("bt"), o.getDouble("vb"), o.getDouble("rb"), o.getBoolean("wh"))
    }
} catch (e: Throwable) { emptyList() }

@Composable
fun Pick(text: String, selected: Boolean, onClick: () -> Unit) {
    val pad = PaddingValues(horizontal = 14.dp)
    if (selected) Button(onClick = onClick, contentPadding = pad) { Text(text, maxLines = 1) }
    else FilledTonalButton(onClick = onClick, contentPadding = pad) { Text(text, maxLines = 1) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf<Uri?>(null) }
    var fileName by remember { mutableStateOf("Belum ada file") }
    var ci by remember { mutableStateOf(0) }
    var si by remember { mutableStateOf(0) }
    var fmt by remember { mutableStateOf(OutFmt.M4A) }
    var srcSel by remember { mutableStateOf(0) }
    var nrSel by remember { mutableStateOf(0) }
    var brSel by remember { mutableStateOf(0) }
    val prefs = remember { ctx.getSharedPreferences("suaraku", 0) }
    var folder by remember { mutableStateOf(prefs.getString("folder", null)?.let { Uri.parse(it) }) }
    var customs by remember { mutableStateOf(loadCustoms(prefs)) }
    var ai by remember { mutableStateOf(false) }
    var recMode by remember { mutableStateOf(true) }
    var recRate by remember { mutableStateOf(48000) }
    var recording by remember { mutableStateOf(false) }
    var level by remember { mutableStateOf(0f) }
    var recSec by remember { mutableStateOf(0) }
    var recorder by remember { mutableStateOf<WavRecorder?>(null) }
    val recFile = remember { File(ctx.cacheDir, "rekaman.wav") }
    var hasRec by remember { mutableStateOf(recFile.exists()) }
    var fxSel by remember { mutableStateOf(0) }
    var cur by remember { mutableStateOf(EFFECTS[0]) }
    var newName by remember { mutableStateOf("") }
    var semi by remember { mutableStateOf(0) }
    val encFile = File(ctx.filesDir, "encoder.onnx")
    val voiceDir = File(ctx.filesDir, "voices").also { it.mkdirs() }
    var encReady by remember { mutableStateOf(encFile.exists()) }
    var voices by remember { mutableStateOf(voiceDir.listFiles()?.map { it.name }?.sorted() ?: emptyList()) }
    var voiceSel by remember { mutableStateOf<String?>(voices.firstOrNull()) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<File?>(null) }
    var resultFmt by remember { mutableStateOf(OutFmt.M4A) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }

    DisposableEffect(Unit) { onDispose { player?.release() } }
    DisposableEffect(busy, recording) {
        view.keepScreenOn = busy || recording
        onDispose { view.keepScreenOn = false }
    }

    fun stopPlayer() { player?.release(); player = null; playing = false }
    fun resetResult() { stopPlayer(); result = null }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            uri = u; resetResult(); status = ""
            var name = "audio"
            ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = c.getString(i)
                }
            }
            val d = try { AudioDecoder.durationMs(ctx, u) } catch (_: Throwable) { 0L }
            fileName = "$name  (${d / 60000}:${(d / 1000 % 60).toString().padStart(2, '0')})"
            if (d > VoiceEngine.MAX_MS + 3000) status = "Durasi lebih dari 10 menit, tidak bisa diproses."
        }
    }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) {
            ctx.contentResolver.takePersistableUriPermission(
                u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            prefs.edit().putString("folder", u.toString()).apply()
            folder = u
        }
    }
    fun folderLabel(u: Uri): String =
        Uri.decode(DocumentsContract.getTreeDocumentId(u)).replace("primary:", "Penyimpanan internal/")
    fun saveToFolder(f: File, name: String, mime: String): Boolean {
        val tree = folder ?: return false
        return try {
            val dir = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val dst = DocumentsContract.createDocument(ctx.contentResolver, dir, mime, name) ?: return false
            ctx.contentResolver.openOutputStream(dst)?.use { o -> f.inputStream().use { it.copyTo(o) } }
            true
        } catch (t: Throwable) { false }
    }
    fun displayName(u: Uri): String {
        var name = "model.onnx"
        ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) name = c.getString(i)
            }
        }
        return name
    }
    fun copyModel(u: Uri, dst: File, after: () -> Unit) {
        busy = true; status = "Menyalin model… (bisa beberapa menit)"
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val tmp = File(dst.path + ".tmp")
                    ctx.contentResolver.openInputStream(u)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    tmp.renameTo(dst)
                }
                after()
                status = "Model tersalin."
            } catch (t: Throwable) { status = "Gagal menyalin: ${t.message}" } finally { busy = false }
        }
    }
    val pickEnc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) copyModel(u, encFile) { encReady = true }
    }
    val pickVoice = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            var n = displayName(u).replace(' ', '_')
            if (!n.endsWith(".onnx")) n += ".onnx"
            copyModel(u, File(voiceDir, n)) {
                voices = voiceDir.listFiles()?.map { it.name }?.sorted() ?: emptyList()
                voiceSel = n
            }
        }
    }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/*")) { u ->
        val f = result
        if (u != null && f != null) {
            ctx.contentResolver.openOutputStream(u)?.use { o -> f.inputStream().use { it.copyTo(o) } }
            status = "Tersimpan."
        }
    }

    fun startProcess() {
        if (busy) return
        val u = uri
        if (!recMode && u == null) return
        busy = true; stopPlayer(); result = null
        job = scope.launch {
            try {
                val out = File(ctx.cacheDir, "hasil.${fmt.ext}")
                val chosen = fmt
                val info = withContext(Dispatchers.Default) {
                    if (recMode) {
                        VoiceEngine.runRecorded(recFile, cur, STYLES[si], chosen, srcSel, nrSel, brSel, fxSel, out, { ensureActive() }, { status = it })
                    } else if (ai) {
                        VoiceEngine.RATE = 44100
                        VoiceEngine.runAi(ctx, u!!, encFile, File(voiceDir, voiceSel ?: ""), semi.toDouble(), chosen, nrSel, brSel, out, { ensureActive() }, { status = it })
                    } else {
                        VoiceEngine.RATE = 44100
                        VoiceEngine.run(ctx, u!!, cur, STYLES[si], chosen, srcSel, nrSel, brSel, fxSel, out, { ensureActive() }, { status = it })
                    }
                }
                result = out; resultFmt = chosen
                status = "Selesai ($info). Tekan Putar untuk preview."
            } catch (e: CancellationException) {
                status = "Dibatalkan."
            } catch (t: Throwable) {
                status = "Gagal: ${t.message}"
            } finally { busy = false }
        }
    }
    fun startRec() {
        stopPlayer(); result = null
        val r = WavRecorder(recRate, recFile, 600, { level = it }, { recSec = it }, {
            recording = false; hasRec = true; level = 0f
            startProcess()
        })
        if (r.start(ctx)) { recorder = r; recording = true; recSec = 0; status = "Merekam…" }
        else status = "Gagal memulai rekaman: ${r.error}"
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRec() else status = "Izin mikrofon ditolak."
    }
    fun toggleRecord() {
        if (recording) recorder?.stop()
        else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRec()
        else permLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("SuaraKu", style = MaterialTheme.typography.headlineMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pick("Rekam", recMode) { if (!recording) { recMode = true; ai = false; resetResult() } }
            Pick("Dari file", !recMode) { if (!recording) { recMode = false; resetResult() } }
        }
        if (recMode) {
            Text("Kualitas rekaman", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pick("44,1 kHz", recRate == 44100) { if (!recording) recRate = 44100 }
                Pick("48 kHz", recRate == 48000) { if (!recording) recRate = 48000 }
            }
            Text("WAV 16-bit mono tanpa kompresi, maks 10 menit. Jaga mic 10-15 cm dari mulut; indikator jangan sampai penuh.")
            LinearProgressIndicator(progress = { level }, modifier = Modifier.fillMaxWidth())
            Text("%d:%02d".format(recSec / 60, recSec % 60) + (if (level > 0.97f) "   PECAH! kecilkan volume / jauhkan mic" else ""))
            Button(onClick = { toggleRecord() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (recording) "Berhenti & terapkan efek" else "Mulai rekam")
            }
            if (hasRec && !recording && !busy) {
                Pick("Simpan rekaman asli (WAV)", false) {
                    val f = folder
                    status = if (f == null) "Pilih folder simpan dulu (di bawah)."
                    else if (saveToFolder(recFile, "suaraku_rekaman_asli.wav", "audio/x-wav")) "Rekaman asli tersimpan di: ${folderLabel(f)}"
                    else "Gagal menyimpan ke folder itu."
                }
                Pick("Terapkan ulang efek ke rekaman", false) { startProcess() }
            }
        } else {
            Button(onClick = { pick.launch(arrayOf("audio/*", "video/*")) }, modifier = Modifier.fillMaxWidth()) {
                Text("Pilih file (.mp3 / .m4a / .mp4, maks 10 menit)")
            }
            Text(fileName)
        }

        if (!recMode) {
        Text("Mesin suara", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pick("Standar (DSP)", !ai) { ai = false; resetResult() }
            Pick("Suara AI (RVC)", ai) { ai = true; resetResult() }
        }
        if (ai) {
            Text(if (encReady) "Encoder ContentVec: siap" else "Encoder ContentVec (.onnx): belum ada")
            Pick(if (encReady) "Ganti encoder" else "Impor encoder", false) { pickEnc.launch(arrayOf("*/*")) }
            Text("Model suara", style = MaterialTheme.typography.titleMedium)
            if (voices.isEmpty()) Text("Belum ada model suara (.onnx)")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                voices.forEach { v -> Pick(v.removeSuffix(".onnx"), v == voiceSel) { voiceSel = v; resetResult() } }
            }
            Pick("Impor model suara", false) { pickVoice.launch(arrayOf("*/*")) }
            Text("Geser nada (semiton)", style = MaterialTheme.typography.titleMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(-12, -6, -3, 0, 3, 6, 12).forEach { s ->
                    Pick(if (s > 0) "+$s" else "$s", s == semi) { semi = s; resetResult() }
                }
            }
            Text("Tips: sumber perempuan ke suara laki-laki biasanya -12; sumber laki-laki ke suara perempuan +12; gender sama 0. Proses AI jauh lebih lambat dari mode standar.")
        }
        }
        if (!ai || recMode) {
        Text("Suara sumber", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Otomatis", "Laki-laki", "Perempuan").forEachIndexed { i, t -> Pick(t, i == srcSel) { srcSel = i; resetResult() } }
        }

        Text("Karakter suara", style = MaterialTheme.typography.titleMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            EFFECTS.forEachIndexed { i, e -> Pick(e.name, e.name == cur.name) { ci = i; cur = e; resetResult() } }
        }
        if (customs.isNotEmpty()) {
            Text("Karakter buatan Anda", style = MaterialTheme.typography.titleMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                customs.forEach { c -> Pick(c.name, c.name == cur.name) { cur = c; resetResult() } }
            }
        }

        Text("Bentuk karakter sendiri", style = MaterialTheme.typography.titleMedium)
        Slide("Nada (0 = ikuti suara asli)", cur.f0, 0f..500f, "%.0f Hz") { cur = cur.copy(f0 = if (it < 50) 0.0 else it); resetResult() }
        Slide("Ukuran suara (1.0 pria, 1.17 wanita, 1.35 anak)", cur.formant, 0.6f..1.7f, "%.2f") { cur = cur.copy(formant = it); resetResult() }
        Slide("Kecepatan", cur.speed, 0.7f..1.4f, "%.2f x") { cur = cur.copy(speed = it); resetResult() }
        Slide("Berdesah", cur.breath, 0f..1f, "%.2f") { cur = cur.copy(breath = it); resetResult() }
        Slide("Terang (+) / gelap (-)", cur.bright, -4f..4f, "%.1f dB/oktaf") { cur = cur.copy(bright = it); resetResult() }
        Slide("Getar suara (vibrato)", cur.vib, 0f..1f, "%.2f semiton") { cur = cur.copy(vib = it); resetResult() }
        Slide("Robot (nada tetap, 0 = mati)", cur.robotHz, 0f..300f, "%.0f Hz") { cur = cur.copy(robotHz = if (it < 40) 0.0 else it); resetResult() }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pick(if (cur.whisper) "Bisik: ON" else "Bisik: OFF", cur.whisper) { cur = cur.copy(whisper = !cur.whisper); resetResult() }
        }
        OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("Nama karakter ini") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pick("Simpan karakter", false) {
                val n = newName.trim()
                if (n.isNotEmpty()) {
                    customs = customs.filter { it.name != n } + cur.copy(name = n)
                    saveCustoms(prefs, customs)
                    cur = cur.copy(name = n); newName = ""
                }
            }
            if (customs.any { it.name == cur.name }) Pick("Hapus '${cur.name}'", false) {
                customs = customs.filter { it.name != cur.name }
                saveCustoms(prefs, customs)
                cur = EFFECTS[0]
            }
        }

        Text("Efek tambahan (mixer)", style = MaterialTheme.typography.titleMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Fx.NAMES.forEachIndexed { i, n -> Pick(n, i == fxSel) { fxSel = i; resetResult() } }
        }

        Text("Gaya intonasi", style = MaterialTheme.typography.titleMedium)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            STYLES.forEachIndexed { i, s -> Pick(s.name, i == si) { si = i; resetResult() } }
        }
        }

        Text("Bersihkan noise", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Mati", "Ringan", "Sedang", "Kuat").forEachIndexed { i, t -> Pick(t, i == nrSel) { nrSel = i; resetResult() } }
        }

        Text("Kurangi suara napas", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Mati", "Ringan", "Sedang", "Kuat").forEachIndexed { i, t -> Pick(t, i == brSel) { brSel = i; resetResult() } }
        }

        Text("Folder simpan", style = MaterialTheme.typography.titleMedium)
        Text(folder?.let { folderLabel(it) } ?: "Belum dipilih (akan ditanya saat menyimpan)")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pick("Pilih folder", false) { pickFolder.launch(null) }
            if (folder != null) Pick("Hapus pilihan", false) { prefs.edit().remove("folder").apply(); folder = null }
        }

        Text("Format hasil", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutFmt.values().forEach { f -> Pick(f.label, f == fmt) { fmt = f; resetResult() } }
        }

        if (status.isNotEmpty()) Text(status)
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())

        if (busy) {
            OutlinedButton(onClick = { job?.cancel() }, modifier = Modifier.fillMaxWidth()) { Text("Batal") }
        } else {
            Button(
                enabled = (recMode && hasRec && !recording) || (!recMode && uri != null && (!ai || (encReady && voiceSel != null))),
                modifier = Modifier.fillMaxWidth(),
                onClick = { startProcess() }
            ) { Text("Proses") }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                enabled = result != null && !busy,
                modifier = Modifier.weight(1f),
                onClick = {
                    if (playing) stopPlayer() else {
                        player = MediaPlayer().apply {
                            setDataSource(result!!.path); prepare()
                            setOnCompletionListener { playing = false }
                            start()
                        }
                        playing = true
                    }
                }
            ) { Text(if (playing) "Berhenti" else "Putar") }
            OutlinedButton(
                enabled = result != null && !busy,
                modifier = Modifier.weight(1f),
                onClick = {
                    val tag = if (ai) "AI_${voiceSel?.removeSuffix(".onnx")}" else "${cur.name}_${STYLES[si].name}"
                    val name = "suaraku_$tag.${resultFmt.ext}".replace(' ', '_')
                    val mime = if (resultFmt == OutFmt.WAV) "audio/x-wav" else "audio/mp4"
                    val f = result
                    if (f != null && folder != null) {
                        status = if (saveToFolder(f, name, mime)) "Tersimpan di: ${folderLabel(folder!!)}"
                        else "Gagal menyimpan ke folder itu. Pilih folder lagi."
                    } else save.launch(name)
                }
            ) { Text("Simpan") }
        }
    }
}
