package com.suaraku.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.nio.ByteOrder

object AudioDecoder {
    fun durationMs(ctx: Context, uri: Uri): Long {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            return r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally { r.release() }
    }

    /** Decode audio (mp3/m4a/mp4) -> mono float pada sample rate [target], diresample langsung saat decode. */
    fun decode(ctx: Context, uri: Uri, target: Int, est: Int, check: () -> Unit): FloatArray {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var idx = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { idx = i; fmt = f; break }
        }
        require(idx >= 0 && fmt != null) { "File tidak punya track audio" }
        ex.selectTrack(idx)

        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        try {
            codec.configure(fmt, null, null, 0)
            codec.start()
            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)

            var out = FloatArray(maxOf(est, target))
            var outN = 0
            var prev = 0f
            var g = 0L
            var nextPos = 0.0
            var lp = 0f

            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            while (!outDone) {
                check()
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val b = codec.getInputBuffer(i)!!
                        val s = ex.readSampleData(b, 0)
                        if (s < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, s, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10_000)
                if (o >= 0) {
                    val b = codec.getOutputBuffer(o)!!
                    b.position(info.offset); b.limit(info.offset + info.size)
                    val sb = b.order(ByteOrder.nativeOrder()).asShortBuffer()
                    val frames = sb.remaining() / ch
                    val ratio = rate.toDouble() / target
                    val filt = rate * 2 > target * 3
                    val a = (1.0 - Math.exp(-2.0 * Math.PI * (0.45 * target) / rate)).toFloat()
                    for (f in 0 until frames) {
                        var m = 0f
                        for (c in 0 until ch) m += sb.get()
                        m = m / ch / 32768f
                        if (filt) { lp += a * (m - lp); m = lp }
                        while (nextPos <= g) {
                            val fr = (nextPos - (g - 1)).toFloat()
                            val v = if (g == 0L) m else prev + (m - prev) * fr
                            if (outN >= out.size) out = out.copyOf(out.size * 2)
                            out[outN++] = v
                            nextPos += ratio
                        }
                        prev = m
                        g++
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = codec.outputFormat
                    rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            return out.copyOf(outN)
        } finally {
            try { codec.stop() } catch (_: Throwable) {}
            codec.release()
            ex.release()
        }
    }
}
