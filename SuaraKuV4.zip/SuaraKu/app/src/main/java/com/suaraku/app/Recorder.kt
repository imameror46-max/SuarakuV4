package com.suaraku.app

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max

/** Perekam WAV 16-bit mono tanpa kompresi (sumber mic mentah bila didukung HP). */
class WavRecorder(
    private val rate: Int,
    private val file: File,
    private val maxSeconds: Int,
    private val onLevel: (Float) -> Unit,
    private val onTime: (Int) -> Unit,
    private val onDone: () -> Unit
) {
    @Volatile private var running = false
    var error: String? = null

    @SuppressLint("MissingPermission")
    fun start(ctx: Context): Boolean {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val unprocessed = am.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED) == "true"
        val src = if (unprocessed) MediaRecorder.AudioSource.UNPROCESSED else MediaRecorder.AudioSource.VOICE_RECOGNITION
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) { error = "Sample rate $rate Hz tidak didukung"; return false }
        val rec = try {
            AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minBuf * 4, rate))
        } catch (t: Throwable) { error = t.message; return false }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release(); error = "Mikrofon tidak bisa dibuka"; return false
        }
        running = true
        Thread {
            var total = 0L
            val raf = RandomAccessFile(file, "rw")
            try {
                raf.setLength(0)
                raf.write(ByteArray(44))
                val buf = ShortArray(rate / 20)
                val bytes = ByteArray(buf.size * 2)
                rec.startRecording()
                while (running && total < rate.toLong() * maxSeconds) {
                    val n = rec.read(buf, 0, buf.size)
                    if (n < 0) break
                    if (n == 0) continue
                    var peak = 0
                    for (i in 0 until n) {
                        val s = buf[i].toInt()
                        bytes[2 * i] = (s and 0xFF).toByte()
                        bytes[2 * i + 1] = ((s shr 8) and 0xFF).toByte()
                        val a = abs(s)
                        if (a > peak) peak = a
                    }
                    raf.write(bytes, 0, n * 2)
                    total += n
                    onLevel(peak / 32768f)
                    onTime((total / rate).toInt())
                }
            } finally {
                try { rec.stop() } catch (_: Throwable) {}
                rec.release()
                val dataBytes = (total * 2).toInt()
                val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
                h.put("RIFF".toByteArray()).putInt(36 + dataBytes).put("WAVE".toByteArray())
                h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1)
                h.putInt(rate).putInt(rate * 2).putShort(2).putShort(16)
                h.put("data".toByteArray()).putInt(dataBytes)
                raf.seek(0); raf.write(h.array()); raf.close()
                running = false
                onDone()
            }
        }.start()
        return true
    }

    fun stop() { running = false }
}

object WavIO {
    /** Baca WAV 16-bit mono buatan perekam ini. Return (sampel, sample rate). */
    fun read(file: File): Pair<FloatArray, Int> {
        RandomAccessFile(file, "r").use { raf ->
            val h = ByteArray(44)
            raf.readFully(h)
            val rate = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN).getInt(24)
            val n = ((raf.length() - 44) / 2).toInt()
            val bytes = ByteArray(n * 2)
            raf.readFully(bytes)
            val sb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            return Pair(FloatArray(n) { sb.get(it) / 32768f }, rate)
        }
    }
}
