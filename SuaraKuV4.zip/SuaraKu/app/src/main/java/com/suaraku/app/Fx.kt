package com.suaraku.app

import kotlin.math.*

/** Efek tambahan ala mixer digital (in-place). */
object Fx {
    val NAMES = listOf("Tanpa", "Echo", "Reverb", "Telepon/Radio", "Logam (robot)")

    fun apply(x: FloatArray, rate: Int, id: Int) {
        when (id) {
            1 -> echo(x, rate)
            2 -> reverb(x, rate)
            3 -> telephone(x, rate)
            4 -> ringMod(x, rate)
        }
    }

    private fun echo(x: FloatArray, rate: Int) {
        val d = (0.28 * rate).toInt()
        val buf = FloatArray(d)
        var p = 0
        for (i in x.indices) {
            val dl = buf[p]
            val inp = x[i]
            buf[p] = inp + dl * 0.35f
            x[i] = inp + dl * 0.35f
            p++; if (p == d) p = 0
        }
    }

    private class Comb(n: Int, val fb: Float) {
        val b = FloatArray(n); var p = 0
        fun proc(x: Float): Float { val o = b[p]; b[p] = x + o * fb; p++; if (p == b.size) p = 0; return o }
    }

    private class Allpass(n: Int) {
        val b = FloatArray(n); var p = 0
        fun proc(x: Float): Float { val bo = b[p]; val o = -x + bo; b[p] = x + bo * 0.5f; p++; if (p == b.size) p = 0; return o }
    }

    private fun reverb(x: FloatArray, rate: Int) {
        fun ms(v: Double) = max(1, (v * rate / 1000).toInt())
        val combs = listOf(29.7, 37.1, 41.1, 43.7).map { Comb(ms(it), 0.78f) }
        val aps = listOf(5.0, 1.7).map { Allpass(ms(it)) }
        for (i in x.indices) {
            val inp = x[i] * 0.25f
            var s = 0f
            for (c in combs) s += c.proc(inp)
            for (a in aps) s = a.proc(s)
            x[i] = x[i] + s * 0.5f
        }
    }

    private class Biquad(b0: Double, b1: Double, b2: Double, a0: Double, a1: Double, a2: Double) {
        private val nb0 = b0 / a0; private val nb1 = b1 / a0; private val nb2 = b2 / a0
        private val na1 = a1 / a0; private val na2 = a2 / a0
        private var z1 = 0.0; private var z2 = 0.0
        fun p(x: Double): Double {
            val y = nb0 * x + z1
            z1 = nb1 * x - na1 * y + z2
            z2 = nb2 * x - na2 * y
            return y
        }
    }

    private fun lowpass(fc: Double, rate: Int): Biquad {
        val w = 2 * PI * fc / rate; val c = cos(w); val a = sin(w) / (2 * 0.7071)
        return Biquad((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + a, -2 * c, 1 - a)
    }

    private fun highpass(fc: Double, rate: Int): Biquad {
        val w = 2 * PI * fc / rate; val c = cos(w); val a = sin(w) / (2 * 0.7071)
        return Biquad((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + a, -2 * c, 1 - a)
    }

    private fun telephone(x: FloatArray, rate: Int) {
        val hp = highpass(320.0, rate); val hp2 = highpass(320.0, rate)
        val lp = lowpass(3400.0, rate); val lp2 = lowpass(3400.0, rate)
        for (i in x.indices) {
            var v = hp2.p(hp.p(x[i].toDouble()))
            v = lp2.p(lp.p(v * 1.6))
            x[i] = tanh(v * 1.3).toFloat()
        }
    }

    private fun ringMod(x: FloatArray, rate: Int) {
        val w = 2 * PI * 55.0 / rate
        for (i in x.indices) x[i] = (x[i] * 0.25f + x[i] * sin(w * i).toFloat() * 0.75f)
    }
}
