package com.suaraku.app

import ai.onnxruntime.OnnxJavaType
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import java.io.File
import java.nio.FloatBuffer
import java.nio.IntBuffer
import java.nio.LongBuffer
import kotlin.math.*

/** Voice conversion RVC v2 offline: ContentVec (768) + F0 Harvest + generator ONNX. */
class RvcEngine(encFile: File, voiceFile: File) : AutoCloseable {
    private val env = OrtEnvironment.getEnvironment()
    private val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(4) }
    private val enc = env.createSession(encFile.path, opts)
    private val gen = env.createSession(voiceFile.path, opts)
    private val rnd = java.util.Random(1234)
    private val hasPitch = gen.inputNames.any { it.lowercase() == "pitch" }

    var outRate = 0
        private set

    override fun close() {
        enc.close(); gen.close(); opts.close()
    }

    /** Return fitur [T*768] dan jumlah frame T (50 fps). */
    private fun encode(a: FloatArray): Pair<FloatArray, Int> {
        val name = enc.inputNames.first()
        val rank = (enc.inputInfo[name]!!.info as TensorInfo).shape.size
        val shape = if (rank == 3) longArrayOf(1, 1, a.size.toLong()) else longArrayOf(1, a.size.toLong())
        val t = OnnxTensor.createTensor(env, FloatBuffer.wrap(a), shape)
        try {
            val r = enc.run(mapOf(name to t))
            try {
                val v = r[0] as OnnxTensor
                val shp = v.info.shape
                val fb = v.floatBuffer
                val data = FloatArray(fb.remaining())
                fb.get(data)
                if (shp.size == 3 && shp[2] == 768L) return Pair(data, shp[1].toInt())
                if (shp.size == 2 && shp[1] == 768L) return Pair(data, shp[0].toInt())
                if (shp.size == 3 && shp[1] == 768L) {
                    val tt = shp[2].toInt()
                    val f = FloatArray(tt * 768)
                    for (i in 0 until tt) for (c in 0 until 768) f[i * 768 + c] = data[c * tt + i]
                    return Pair(f, tt)
                }
                throw IllegalStateException("Output encoder tidak dikenali (harus ContentVec 768 dimensi): ${shp.toList()}")
            } finally { r.close() }
        } finally { t.close() }
    }

    private fun intTensor(ti: TensorInfo, v: LongArray, shape: LongArray): OnnxTensor =
        if (ti.type == OnnxJavaType.INT32)
            OnnxTensor.createTensor(env, IntBuffer.wrap(IntArray(v.size) { v[it].toInt() }), shape)
        else OnnxTensor.createTensor(env, LongBuffer.wrap(v), shape)

    /** a16: audio 16 kHz. Hasil: audio pada [outRate]. */
    fun convert(a16: FloatArray, semitone: Double): FloatArray {
        val (feats, tf) = encode(a16)
        val f0 = if (hasPitch) NativeVoice.f0Track(DoubleArray(a16.size) { a16[it].toDouble() }, 16000) else DoubleArray(0)
        val T = if (hasPitch) min(tf * 2, f0.size) else tf * 2
        require(T > 0) { "Audio terlalu pendek" }

        val ph = FloatArray(T * 768)
        for (i in 0 until T) System.arraycopy(feats, min(i / 2, tf - 1) * 768, ph, i * 768, 768)

        val pitch = LongArray(T)
        val pitchf = FloatArray(T)
        if (hasPitch) {
            val ratio = 2.0.pow(semitone / 12.0)
            val melMin = 1127.0 * ln(1.0 + 50.0 / 700.0)
            val melMax = 1127.0 * ln(1.0 + 1100.0 / 700.0)
            for (i in 0 until T) {
                val f = f0[i] * ratio
                pitchf[i] = f.toFloat()
                var m = 1127.0 * ln(1.0 + f / 700.0)
                if (m > 0) m = (m - melMin) * 254.0 / (melMax - melMin) + 1.0
                if (m <= 1.0) m = 1.0
                if (m > 255.0) m = 255.0
                pitch[i] = m.roundToLong()
            }
        }

        val tensors = ArrayList<OnnxTensor>()
        try {
            val feeds = HashMap<String, OnnxTensor>()
            for (name in gen.inputNames) {
                val ln = name.lowercase()
                val ti = gen.inputInfo[name]!!.info as TensorInfo
                val tensor = when {
                    ln == "phone" || ln == "feats" -> {
                        val d = ti.shape.last()
                        require(d == 768L || d < 0) { "Model suara ini versi 1 (256 dimensi). Gunakan model RVC v2." }
                        OnnxTensor.createTensor(env, FloatBuffer.wrap(ph), longArrayOf(1, T.toLong(), 768))
                    }
                    ln.endsWith("lengths") || ln == "p_len" -> intTensor(ti, longArrayOf(T.toLong()), longArrayOf(1))
                    ln == "pitch" -> intTensor(ti, pitch, longArrayOf(1, T.toLong()))
                    ln == "pitchf" -> OnnxTensor.createTensor(env, FloatBuffer.wrap(pitchf), longArrayOf(1, T.toLong()))
                    ln == "ds" || ln == "sid" -> intTensor(ti, longArrayOf(0), longArrayOf(1))
                    ln == "rnd" -> {
                        val ch = if (ti.shape.size == 3 && ti.shape[1] > 0) ti.shape[1].toInt() else 192
                        val nz = FloatArray(ch * T) { (rnd.nextGaussian() * 0.66666).toFloat() }
                        OnnxTensor.createTensor(env, FloatBuffer.wrap(nz), longArrayOf(1, ch.toLong(), T.toLong()))
                    }
                    else -> throw IllegalStateException("Input model tidak dikenali: $name (daftar input: ${gen.inputNames})")
                }
                tensors.add(tensor)
                feeds[name] = tensor
            }
            val r = gen.run(feeds)
            try {
                val o = r[0] as OnnxTensor
                val fb = o.floatBuffer
                val audio = FloatArray(fb.remaining())
                fb.get(audio)
                val spf = audio.size.toDouble() / T * 100.0
                outRate = listOf(32000, 40000, 44100, 48000).minByOrNull { abs(it - spf) }!!
                return audio
            } finally { r.close() }
        } finally { tensors.forEach { it.close() } }
    }
}
