package com.suaraku.app

import kotlin.math.*

/** Resampler windowed-sinc (kualitas tinggi, anti-aliasing). */
object Resample {
    fun run(x: FloatArray, inR: Int, outR: Int): FloatArray {
        if (inR == outR) return x
        val ratio = inR.toDouble() / outR
        val cutoff = min(1.0, outR.toDouble() / inR) * 0.94
        val half = 10
        val width = half / cutoff
        val os = 256
        val m = (width * os).toInt()
        val tab = FloatArray(2 * m + 1) { k ->
            val d = (k - m).toDouble() / os
            val a = cutoff * d
            val s = if (abs(a) < 1e-9) 1.0 else sin(PI * a) / (PI * a)
            (cutoff * s * (0.5 + 0.5 * cos(PI * d / width))).toFloat()
        }
        val outN = (x.size / ratio).toInt()
        val res = FloatArray(outN)
        for (j in 0 until outN) {
            val c = j * ratio
            val lo = max(0, ceil(c - width).toInt())
            val hi = min(x.size - 1, floor(c + width).toInt())
            var s = 0f
            for (i in lo..hi) {
                val idx = (((i - c) * os).roundToInt() + m).coerceIn(0, 2 * m)
                s += x[i] * tab[idx]
            }
            res[j] = s
        }
        return res
    }
}
